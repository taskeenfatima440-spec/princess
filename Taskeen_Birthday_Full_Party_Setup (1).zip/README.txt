Taskeen Fatima Birthday Full Party Website

Open index.html in Chrome. All three pictures are embedded in the page, so no separate images folder is needed.

Includes animated homepage, golden name, birthday cake, candle-blowing, cake-cutting animation, party confetti, floating decorations, photo gallery, surprise message and responsive mobile/laptop layout.
